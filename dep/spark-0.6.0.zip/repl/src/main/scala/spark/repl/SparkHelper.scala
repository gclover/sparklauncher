package scala.tools.nsc

object SparkHelper {
  def explicitParentLoader(settings: Settings) = settings.explicitParentLoader
}
